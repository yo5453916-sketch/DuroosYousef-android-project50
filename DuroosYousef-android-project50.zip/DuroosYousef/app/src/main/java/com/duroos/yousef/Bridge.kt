package com.duroos.yousef

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.io.OutputStream
import java.lang.ref.WeakReference
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class Bridge(private val ctx: Context) {
  companion object {
    @Volatile var web: WeakReference<WebView>? = null
    private val ui = Handler(Looper.getMainLooper())
    fun js(code: String) { ui.post { web?.get()?.evaluateJavascript(code, null) } }
    fun cmd(c: String) = js("window.nativeCmd&&nativeCmd('$c')")
  }
  private val pool = Executors.newFixedThreadPool(4)
  private class Sess(val uri: Uri, val os: OutputStream)
  private val saves = ConcurrentHashMap<String, Sess>()

  @JavascriptInterface fun media(title: String, artist: String, playing: Boolean, pos: Long, dur: Long) {
    MediaService.title = title; MediaService.artist = artist; MediaService.playing = playing; MediaService.pos = pos; MediaService.dur = dur
    ui.post {
      val s = MediaService.inst
      if (s != null) s.refresh()
      else if (playing) { val i = Intent(ctx, MediaService::class.java); try { ctx.startForegroundService(i) } catch (e: Exception) {} }
    }
  }
  @JavascriptInterface fun stop() { ui.post { ctx.stopService(Intent(ctx, MediaService::class.java)) } }
  @JavascriptInterface fun exit() { ui.post { ctx.stopService(Intent(ctx, MediaService::class.java)); (ctx as? android.app.Activity)?.finishAndRemoveTask() } }

  // جلب صفحات (يتخطى CORS)
  @JavascriptInterface fun nget(id: Int, url: String) {
    pool.execute {
      var st = 0; var cs = ""; var b64 = ""
      try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        c.setRequestProperty("Accept-Language", "ar,en;q=0.8")
        st = c.responseCode
        cs = (c.contentType ?: "").substringAfter("charset=", "").trim().ifEmpty { "utf-8" }
        if (st in 200..299) b64 = Base64.encodeToString(c.inputStream.readBytes(), Base64.NO_WRAP)
      } catch (e: Exception) { st = 0 }
      js("window.__ng($id,$st,'${cs.replace("'", "")}','$b64')")
    }
  }

  // حفظ في Music/Duroos
  @JavascriptInterface fun beginSave(name: String, type: String): String {
    return try {
      val v = ContentValues().apply {
        put(MediaStore.Audio.Media.DISPLAY_NAME, name); put(MediaStore.Audio.Media.MIME_TYPE, type)
        put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Duroos"); put(MediaStore.Audio.Media.IS_PENDING, 1)
      }
      val uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v) ?: return ""
      val os = ctx.contentResolver.openOutputStream(uri) ?: return ""
      val id = java.util.UUID.randomUUID().toString(); saves[id] = Sess(uri, os); id
    } catch (e: Exception) { "" }
  }
  @JavascriptInterface fun writeChunk(id: String, b64: String): Boolean =
    try { saves[id]!!.os.write(Base64.decode(b64, Base64.DEFAULT)); true } catch (e: Exception) { false }
  @JavascriptInterface fun endSave(id: String, ok: Boolean): String {
    val s = saves.remove(id) ?: return ""
    return try {
      s.os.close()
      if (ok) { val v = ContentValues(); v.put(MediaStore.Audio.Media.IS_PENDING, 0); ctx.contentResolver.update(s.uri, v, null, null); s.uri.toString() }
      else { ctx.contentResolver.delete(s.uri, null, null); "" }
    } catch (e: Exception) { "" }
  }
  @JavascriptInterface fun deleteFile(uri: String) { try { ctx.contentResolver.delete(Uri.parse(uri), null, null) } catch (e: Exception) {} }

  @JavascriptInterface fun openVlc(u: String, t: String): String {
    return try {
      val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "audio/*").setPackage("org.videolan.vlc")
        .putExtra("title", t).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
      ctx.startActivity(i); "ok"
    } catch (e: ActivityNotFoundException) {
      try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=org.videolan.vlc")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) {}
      "novlc"
    } catch (e: Exception) { "err" }
  }
}
